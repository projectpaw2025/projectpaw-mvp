Drop WOFF2 files here as named in @font-face above for self-hosting.
